﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ucakrezervasyon
{
    internal class Rezervasyon
    {
        public int Id { get; set; }
        public Ucus Ucus { get; set; }
        public string Ad { get; set; }
        public string Soyad { get; set; }
        public int Yas { get; set; }
        public int BiletNo { get; set; }
    }
}
