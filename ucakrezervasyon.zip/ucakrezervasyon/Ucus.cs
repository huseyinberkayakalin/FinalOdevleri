﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ucakrezervasyon
{
    internal class Ucus
    {
        public int UcusId { get; set; }
        public int LokasyonId { get; set; }
        public DateTime Tarih { get; set; }
        public DateTime Saat { get; set; }
        public Ucak Ucak { get; set; }
        public bool AktifPasif { get; set; }
    }
}
